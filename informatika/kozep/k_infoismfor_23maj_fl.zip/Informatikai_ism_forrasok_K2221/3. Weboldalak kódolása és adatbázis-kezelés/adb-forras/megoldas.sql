-- 8.feladat


-- 10.feladat


-- 11.feladat


-- 12.feladat


-- 13.feladat


-- 14.feladat


-- 15.feladat

