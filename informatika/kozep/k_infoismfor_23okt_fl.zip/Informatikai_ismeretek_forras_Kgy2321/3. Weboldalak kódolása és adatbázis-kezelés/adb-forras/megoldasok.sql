-- 10. feladat:


-- 12. feladat:


-- 13. feladat:


-- 14. feladat:


-- 15. feladat:


-- 16. feladat:

